A= load("obstclae.mat");
A = A.Problem.A;
A_pattern = spones(A);

A_pattern1 = A_pattern;

A_pattern4 = A_pattern^4;

%%
tic
guess = apx_dA_sparse(A,A_pattern1)
toc
%%
tic
guess = apx_dA_sparse(A,A_pattern4)
toc

