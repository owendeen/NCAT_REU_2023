# -*- coding: utf-8 -*-
import numpy as np
import scipy as sp
from scipy.sparse import csr_matrix
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import laplacian
"""
the main functions of the project for approximating the function d(A)
Contents:
        section 1: approximation from a given pattern
    1.1   := slicing
    1.2.1 := backsubstitution for cholesky factorization
    1.2.2 := cholesky factorization
    1.3   := apx_dA_sparse

        section 2: generate sparsity pattern(s) and approximation from given pattern(s)
                        patterns come from powers of the initial sparsity pattern of A
    2.1   := generate pattern and approximate
    ^*
    
        section 3: use splines to predict to a power
    3.1   := (for spline apx) generate patterns up to a power and approximate
    3.2   := create a laplacian from an adjacency array
    3.3   := from approximations and sparsities create array and predict using splines

^* indicates a most-important function
"""

#%% Section 1
"""
    section 1: approximation from a given pattern
1.1   := slicing
1.2.1 := backsubstitution for cholesky factorization
1.2.2 := cholesky factorization
1.3   := apx_dA_sparse
"""

#1.1
def projection_slicing(A, pattern, i):
    nnz_cols = pattern.indices[pattern.indptr[i]:pattern.indptr[i+1]]   #col index of nnz vals
    A_i = (A[ nnz_cols ,:])[:,nnz_cols]                         #slicing according to the P_i * A * P_i^T
    return(A_i)
    
#1.2.1
def forward_subs(G,b):
    n = G.shape[0]
    x = np.zeros((n,),dtype = float)
    x[0] = b[0]/G[0,0]	
    for ii in range(1,n):
        x[ii] = b[ii] - G[ii,:ii]@x[:ii]
        x[ii] /= G[ii,ii]
    return(x)
#1.2.2
def cholesky_factor(A):
    # bordered
    n = A.shape[0]
    R = np.zeros(A.shape,dtype=float)
    R[0,0] = A[0,0]**0.5
    for ii in range(1,n):
        c = A[0:ii,ii]
        Ri0 = R[:ii,:ii]
        h = forward_subs(Ri0.T,c.T).flatten()
        R[0:ii,ii] = h
        R[ii,ii] = (A[ii,ii]-h.T@h)**0.5
    L = R.T
    return(L)

#1.3
def apx_dA_sparse(A,pattern):
    m,n = A.get_shape()
    pattern = sp.sparse.tril(pattern, format='csr')     #format the pattern
    apx_of_dA = 1                                       #initialize the apx
    
    for i in range(n):
        A_i = projection_slicing(A, pattern, i)
        L_i = cholesky_factor(A_i.toarray())
        apx_of_dA *= (L_i[-1,-1])**(2/n)
    return(apx_of_dA)




#%%Section 2
"""
    section 2: generate sparsity pattern(s) and approximation from given pattern(s)
                    patterns come from powers of the initial sparsity pattern of A
2.1   := generate pattern and approximate
^*
"""

#2.1
def pat_apx(A, apx_to_power):
    A_pattern = A != 0
    A_pattern = A_pattern**(apx_to_power)       #generate pattern
    apx_of_dA = apx_dA_sparse(A , A_pattern)    #apx
    return(apx_of_dA)




#%% Section 3
"""
    section 3: use splines to predict to a power
3.1   := (for spline apx) generate patterns up to a power and approximate
3.2   := create a laplacian from an adjacency array
3.3   := from approximations and sparsities create array and predict using splines
^*
"""


#3.1
def apxs_for_spline(A,apx_start_power ,apx_to_power,apx_to_by_spline ):
    m,n = A.get_shape()
    total_entries = m*n
    sparsities = np.zeros(  (apx_to_power +1 - (apx_start_power-1)) )   #initilize storage of sparsities
    apxs = np.zeros(apx_to_power- (apx_start_power-1))
    
    A_pattern = A != 0
    A1 = A_pattern              #generate and store the first pattern
    
    if apx_start_power >1:
        for loop in range(apx_start_power):
            A_pattern = A_pattern @ A1
        
    
    for i in range( apx_to_power- (apx_start_power-1)):               #loop to generate apxs and sparsities
        tot_nzs = A_pattern.count_nonzero()
        sparsities[i] = tot_nzs/total_entries
        apxs[i] = apx_dA_sparse(A, A_pattern)
        A_pattern = A_pattern @ A1
    
    diff = apx_to_by_spline - apx_to_power      #this is to see how far out to generate a pattern to collect its sparsity
    
    for loop in range(diff-1):
        A_pattern = A_pattern @ A1
        
    tot_nzs = A_pattern.count_nonzero()
    
    sparsities[-1] = tot_nzs/total_entries
    return(apxs , sparsities)

#3.2
def laplacian_(graph_arr):
    adj_arr = np.array(graph_arr, dtype=bool)
    leng = np.shape(graph_arr)
    deg_arr = np.zeros((leng[0] , leng[0]))
    for i in range(leng[0]):
        deg_arr[i,i] = sum(adj_arr[i] !=0)

    lap_arr = deg_arr - adj_arr
    return(lap_arr)
    

#3.3
def spline_apx(A, apx_start_power,apx_to_power,apx_to_by_spline):
    apxs, sparsities = apxs_for_spline(A, apx_start_power,apx_to_power,apx_to_by_spline )
    
    graph_arr = np.zeros((len(sparsities) , len(sparsities)))     #initilize adjaceny array
    
    for k in range(len(sparsities)-1):
        weightt = 1/(sparsities[k+1] - sparsities[k]) #distance is difference in sparsity percents. weight is reciprocal of that. 
        graph_arr[k,k+1] = weightt
        graph_arr[k+1,k] = weightt
        #manually goes through entire adjacency array, but that array is very small
    
    lap_arr = laplacian_(graph_arr)    


    A_ = lap_arr[:,-1]                         
    A_ = np.reshape(A_, (len(A_),1))                

    b_ = -np.matmul( lap_arr[:,:-1], apxs)    
    b_ = np.reshape(b_, (len(b_),1))                

    y = np.linalg.lstsq(A_,b_ , rcond=-1)
    spline_apx_ = y[0][0][0]
    
    return(spline_apx_)






