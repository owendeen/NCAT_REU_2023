# -*- coding: utf-8 -*-
"""
other python functions

        section 1: dense version of functions
    1.1   := dense apx function
    1.2   := paper method of approximation
    1.3   := spline method of approximation
        
        section 2: Ghat generation
    2.1   := dA apx function for ghat generation
    2.2   := Ghat generation in csr format
    
        section 3: sparsity pattern generation by removing lowest values and squaring 
                    resulting sparsity pattern
    3.1   := dA apx function for different sparsity patterns
    3.2   := generates different sparsity patterns and apxs


  
*these functions still use scipy cholesky and scipy laplacian
"""
import numpy as np
from scipy.linalg import cholesky
import scipy as sp
from scipy.sparse.csgraph import laplacian
from scipy.sparse import csr_matrix
from scipy.sparse import linalg
from scipy.sparse import coo_matrix
from pat_apx import pat_apx



def apx_dA_dense(A , pattern):
    #pattern inputed should not be tril (it can be tho, just redundancy)
    
    #initiliaze lists and some prep
    m,n = np.shape(A)
    pattern = np.tril(pattern)
    apx_of_dA = 1 #these are the L_i_ni,ni s
    
    #now to calculate the gamma_i_s and store them
    for i in range(n):  #i is the ith row
        
        A_i = (A[pattern[i] ,:])[:,pattern[i]]
            #may not even need pattern, and can just generate the pattern[i]s as going, but idk if thats faster or not
        
        L_i = sp.linalg.cholesky(A_i, lower=True, overwrite_a=False, check_finite=True)
        
        gamma_i = (L_i[-1,-1])**(2/n)
        apx_of_dA = gamma_i *apx_of_dA
    return(apx_of_dA)


def pure_powerpat_apx_dense(A , apx_to_power, more_than_one_apx = True, save_spspat = False):
    #the first True is whether you want just one apx or all of the ones leading up to it
    #if the save_spat is true, that is for the spline apx
    if more_than_one_apx == False:
        A_pattern = A != 0
        A_pattern = np.linalg.matrix_power(A_pattern , apx_to_power)
        apx_of_dA = apx_dA_dense(A , A_pattern)
        return(apx_of_dA)
    
    else:
        m,n = np.shape(A)
        total_entries = m*n
        sparsities = np.zeros(apx_to_power+1)
        
        
        A1 = A != 0
        tot_nzs = np.count_nonzero(A1)
        sparsities[0] = tot_nzs/total_entries
        
        
        apxs = np.zeros(apx_to_power)
        apxs[0] = apx_dA_dense(A , A1)
        
        A_pattern = A1
        
        for i in range(apx_to_power-1):
            A_pattern = A_pattern @ A1
            
            apxs[i+1] = apx_dA_dense(A , A_pattern)
            
            tot_nzs = np.count_nonzero(A_pattern)
            sparsities[i+1] = tot_nzs/total_entries
        if save_spspat== False:
            return(apxs, sparsities)
        else:
            return(apxs, sparsities, [A1,A_pattern], total_entries)


def graph_spline_apx_dense(A , apx_to_power , apx_to_by_spline): 
    apxs, sparsities, patterns, total_entries = pure_powerpat_apx_dense(A , apx_to_power, more_than_one_apx = True, save_spspat = True)
    
    nu = apx_to_by_spline - apx_to_power  #check how far we need to go
    
    for loop in range(nu):
        patterns[1] = patterns[1] @ patterns[0]
    
    
    tot_nzs = np.count_nonzero( patterns[1])
    
    sparsities = list(sparsities)
    sparsities[-1] = (tot_nzs/total_entries)
    
    adj_arr = np.zeros((len(sparsities) , len(sparsities)))
    
    for k in range(len(sparsities)-1):
        weightt = 1/(sparsities[k+1] - sparsities[k]) #distance is difference in sparsity percents. weight is reciprocal of that
        adj_arr[k,k+1] = weightt
        adj_arr[k+1,k] = weightt
        
    lap_arr = laplacian(adj_arr)
    print(lap_arr)
    
    A_ = lap_arr[:,-1]                         #only the last two cols of the laplacian::: (-2,-1) for last two. -1 for last 1
    A_ = np.reshape(A_, (len(A_),1))                #necessary for predicting only last column

    b_ = -np.matmul( lap_arr[:,:-1], apxs)    #all but the last two cols of the laplacian
    b_ = np.reshape(b_, (len(b_),1))                #necessary for predicting only last column

    y = np.linalg.lstsq(A_,b_ , rcond=-1)
    spline_apx_ = y[0][0][0]
    
    return(spline_apx_ , adj_arr)


"""
section 2
"""
def apx_dA(A , pattern):
    m,n = A.get_shape()
    pattern = sp.sparse.tril(pattern, format='csr')
    Ghat_El_rows = list(np.zeros(n)) #these are the L_i_ni,ni s
    
    #now to calculate the gamma_i_s and store them
    for i in range(n):  #i is the ith row
        nonzero_cols = pattern.indices[pattern.indptr[i]:pattern.indptr[i+1]] #in row i, col number of nonzeros
        A_i = (A[ nonzero_cols ,:])[:,nonzero_cols]   #takes rows according to Pi A , then A PiT
                                #may be able to do A_i in one slice, but I don't think so
                                #A_i is square. size = (number of nonzeros in row i of pattern)^2
      
        ehat_i = np.zeros(( len(nonzero_cols) ,1))
        ehat_i[-1,0] = 1
        
        ghat_i = sp.linalg.solve(A_i.toarray(), ehat_i )
        
        g_i = np.zeros(n)
        g_i[nonzero_cols]= np.transpose(ghat_i)
        g_i = sp.sparse.csr_array(g_i)
        
        Ghat_El_rows[i] = g_i
        
    Ghat_El = sp.sparse.vstack(Ghat_El_rows).tocsr()
    
    apx_of_dA = np.prod(sp.sparse.csr_matrix.diagonal(Ghat_El) **(-1/n))
    
    return(apx_of_dA, Ghat_El)



def pure_powerpat_apx(A , apx_to_power):
    m,n = A.get_shape()
    total_entries = m*n
    sparsities = np.zeros(apx_to_power)
    
    A1 = A != 0
    tot_nzs = A1.count_nonzero() 
    sparsities[0] = tot_nzs/total_entries
    
    apxs = np.zeros(apx_to_power)
    list_of_Ghats = list(np.zeros(apx_to_power))
    apxs[0] , list_of_Ghats[0] = apx_dA(A , A1)
    
    A_pattern = A1
    
    for i in range(apx_to_power-1):
        A_pattern = A_pattern @ A1
        apxs[i+1] , list_of_Ghats[i+1] = apx_dA(A , A_pattern)
        
        tot_nzs = A_pattern.count_nonzero() 
        sparsities[i+1] = tot_nzs/total_entries
    return(apxs , sparsities, list_of_Ghats)


"""
section 3: alternate sparsity pattern generation
"""
def pat_apx(A , pattern):
    m,n = A.get_shape()
    pat = sp.sparse.tril(pattern, format='csr')
    base = sp.sparse.csr_array((n,n))
    Ghat_El_rows = list(np.zeros(n))
    for i in range(n): #i is the row we work with in A
        nonzero_cols = pat.indices[pat.indptr[i]:pat.indptr[i+1]] #in row i, col number of nonzeros
        
        first_projection = sp.sparse.linalg.inv( (A[ nonzero_cols ,:])[:,nonzero_cols]  )  #slice according to projection then inverse then slice then slice
        
        second_projection = sp.sparse.csr_array((n,len(nonzero_cols)))
        second_projection[ nonzero_cols , 0:len(nonzero_cols) ]   =  first_projection 
        
        third_projection = base.copy()
        third_projection[ : , nonzero_cols ] = second_projection
        
        fourth_projection = sp.sparse.csr_array.transpose(third_projection[:,[i]]).tocsr()   #the e_i projection
        #maybe I should delete the "first projection" and stuff after I use them to open some memory up
        #while it's running
        
        Ghat_El_rows[i] = fourth_projection.copy() #idk if the copy is necessary
        

    
    Ghat_El = sp.sparse.vstack(Ghat_El_rows).tocsr()
    diagonals = sp.sparse.csr_matrix.diagonal(Ghat_El) **(-1/n)
    apx = np.prod(diagonals)
    print("Ghat_El and apx complete")
        
    return(apx, Ghat_El, n)



def pat_rem_apx(A , num_of_rem_pats = 3 , list_Ghats = True):
    A1 = A != 0
    Ghat_El_list = list(np.zeros(num_of_rem_pats+1))      #initilize Ghat list
    apxs_from_sprs = list(np.zeros(num_of_rem_pats+1))                 #initilize apxs list
    count_entries = list(np.zeros(num_of_rem_pats+1))
    
    apx , Ghat_El, n = pat_apx(A, A1)     #calculate the apx and Ghat of A1
    
    apxs_from_sprs[0] = apx
    if list_Ghats == True:
        Ghat_El_list[0] = Ghat_El
        
    count_entries[0] = len(Ghat_El.data)

    
    
    for k in range(1, num_of_rem_pats+1 ): 
        if n >1000: rsplit = 100 ; num_of_splits = int(n/rsplit) #deciding how to split the rows of A
        elif n<20: rsplit = 1 ; num_of_splits =n
        else: rsplit = int(n/20) ; num_of_splits =20
        
        #rsplit = n ; num_of_splits = 1
        all_split_mx = [] 
        #split the matrix by rows
        for jj in range(num_of_splits):
            
            split_mx = Ghat_El[jj*rsplit:(jj+1)*rsplit , : ]
            all_split_mx.append(split_mx)   
            
            tenth_ = int(len(split_mx.data)/10) -1 #tenth of the values in the split
            values_to_lose = (np.argpartition( split_mx.data,tenth_,0))[0:tenth_+1 ]
            split_mx.data[values_to_lose] = 0
            #the 
            
            if (jj==num_of_splits-1) and not((n%rsplit == 0)):  #if there is a remainder, will do a slice of remaining rows
                split_mx = Ghat_El[(jj+1)*rsplit: , : ]
                all_split_mx.append(split_mx)   
            
                tenth_ = int(len(split_mx.data)/10) -1 #tenth of the values in the split
                values_to_lose = (np.argpartition( split_mx.data,tenth_,0))[0:tenth_+1 ]
                split_mx.data[values_to_lose] = 0      #removing the small values


        Ghat_wo_smalls = sp.sparse.vstack(all_split_mx)
        if (0 in sp.sparse.csr_matrix.diagonal(Ghat_wo_smalls)):
            print('Error, one of the diagonals was made zero when making the in-betweens')
        
        pattern_wo_smalls = Ghat_wo_smalls != 0
        #make boolean pattern from removing the small values (this is a smaller sparsity pattern than A1)
        
        pattern_wo_smalls_squared = pattern_wo_smalls**2
        
        apx , Ghat_El, n = pat_apx(A, pattern_wo_smalls_squared)
        
        apxs_from_sprs[k] = apx
        
        if list_Ghats == True:
            Ghat_El_list[k] = Ghat_El
        
        count_entries[k] = len(Ghat_El.data)
            
    return( apxs_from_sprs , Ghat_El_list , count_entries )