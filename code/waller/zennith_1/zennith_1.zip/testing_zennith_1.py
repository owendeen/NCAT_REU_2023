# -*- coding: utf-8 -*-
"""
testing for zennith_functions_1
"""

from zennith_functions_1 import *

import time
from generate_matrices import laplacian_grid,florida_sparse


dim_enter = 30
A = laplacian_grid(dim_enter) 


#actual value
m,n = A.get_shape()
A_LU = sp.sparse.linalg.splu(A)     # LU decomp
actual_value_calculated = (A_LU.U.diagonal() **(1/(n))  ).prod()



ts0 = time.time()

spline_apx_  = spline_apx(A ,1, 4,  6)

ts1 = time.time()
print(ts1-ts0)
print('our error',(abs(spline_apx_ - actual_value_calculated)*100))


ts0 = time.time()
dA_apx = pat_apx(A,6)
ts1 = time.time()
print(ts1-ts0)
print('paper error',(abs(dA_apx - actual_value_calculated)*100))


