# -*- coding: utf-8 -*-
"""
new file to calculate G and do the approx stuff. NOT a function. Function 
is on the other file
"""
#%%this is here just to generate the matrices to work with. will be deleted at end when made function
from generate_matrices import laplacian_grid, florida_sparse

import numpy as np
import scipy as sp
from scipy.sparse import csr_matrix
from scipy.sparse import coo_matrix
from scipy.sparse import linalg
import time

dim_enter = 50
A = laplacian_grid(dim_enter)       #generate input^2 x input^2 matrix
m,n = A.get_shape()
orders_of_A = 4             #power of A to go to

A_LU = sp.sparse.linalg.splu(A)     # LU decomp
actual_det = A_LU.L.diagonal().prod() * A_LU.U.diagonal().prod()      #product of the products of the diagonal entries of the LU decomp
actual_value = actual_det**(1 / (dim_enter**2))


A1 = A != 0
sprs_ptts = [A1]
for k in range(2,orders_of_A+1):
    sprs_ptts.append( (sprs_ptts[0])**k )

viewing_mxs = []
for k in range(orders_of_A):
    viewing_mxs.append( sprs_ptts[k].todense())

#%% input are the boolean arrays of where values are


inputt = sprs_ptts[1]
#inputt = A1_2
pattern = sp.sparse.tril(inputt, format='csr')
base = sp.sparse.csr_array((n,n))
#Ghat_El = base.copy()

#pattern= sparsity pattern    A=array to be sliced    
#for slicing, im not sure if I should switch back and forth between csr and csc formats for higher speed


for i in range(n): #i is the row we work with in A
    nonzero_cols = pattern.indices[pattern.indptr[i]:pattern.indptr[i+1]] #in row i, col number of nonzeros of the spsty pattern
    
    first_projection = sp.sparse.linalg.inv( (A[ nonzero_cols ,:])[:,nonzero_cols]  )  #slice according to projection then inverse then slice then slice
    
    second_projection = sp.sparse.csr_array((n,len(nonzero_cols)))
    second_projection[ nonzero_cols , 0:len(nonzero_cols) ]   =  first_projection 
    
    third_projection = base.copy()
    third_projection[ : , nonzero_cols ] = second_projection
    
    fourth_projection = sp.sparse.csr_array.transpose(third_projection[:,[i]]).tocsr()   #the e_i projection
            #i could just store the ith value of the "fourth projection" into a list and then do the power and prod of them
            #without having to store all the other values
    if i == 0:
        Ghat_El = (fourth_projection.copy())
    else:
        Ghat_El = sp.sparse.vstack([Ghat_El, (fourth_projection.copy())])
        #should likely replace with one big vstack at the end and preallocate with a dok or something

#working script for making Ghat's from the boolean A1, A2, etc.. 
#now to perform the math on the Ghat_El to find the apprx

#try the big PI method

diagonals = sp.sparse.csr_matrix.diagonal(Ghat_El.tocsr()) **(-1/n)
apprx = np.prod(diagonals)

#%%
view_Ghat_El = Ghat_El.toarray()


if n >1000: rsplit = 100 ; num_of_splits = int(n/rsplit)
elif n<20: rsplit = 1 ; num_of_splits =n
else: rsplit = int(n/20) ; num_of_splits =20


#have ghat and the how many rows we'll be splitting by
all_split_mx = [] 
#split the matrix by rows
for k in range(num_of_splits):
    
    split_mx = Ghat_El[k*rsplit:(k+1)*rsplit , : ]
    all_split_mx.append(split_mx)   
    
    tenth_ = int(len(split_mx.data)/10) -1 #tenth of the values in the split
    values_to_lose = (np.argpartition( split_mx.data,tenth_,0))[0:tenth_+1 ]
    split_mx.data[values_to_lose] = 0
        #the 
        
    if (k==num_of_splits-1) and not((n%rsplit == 0)):  #if there is a remainder, will do a slice of remaining rows
        split_mx = Ghat_El[(k+1)*rsplit: , : ]
        all_split_mx.append(split_mx)   
        
        tenth_ = int(len(split_mx.data)/10) -1 #tenth of the values in the split
        values_to_lose = (np.argpartition( split_mx.data,tenth_,0))[0:tenth_+1 ]
        split_mx.data[values_to_lose] = 0


new_A_inbetween = sp.sparse.vstack(all_split_mx)


#need to make sure that all diagonals were kept. they should be kept but want to make sure for now
if (0 in sp.sparse.csr_matrix.diagonal(new_A_inbetween)):
    print('Error, one of the diagonals was made zero when making the in-betweens')


A1_2 = new_A_inbetween != 0


#this new A1_2 worked!!!! i might be able to cut even more than a tenth of the smallest out

#%% now to go through and make inbetweens








#%% testing
test = pattern.indices[pattern.indptr[10]:pattern.indptr[10+1]]
first_projection = sp.sparse.linalg.inv( ((A[ test ,:])[:,test] ) )

second_projection = sp.sparse.csr_array((n,len(test)))
second_projection[ test , 0:len(test) ]   =  first_projection        #maybe convert to lil_matrix to change structure

third_projection = sp.sparse.csr_array((n,n))
third_projection[ : , test ] = second_projection

fourth_projection = sp.sparse.csr_array.transpose(third_projection[:,[10]]).tocsr()
Ghat_El = fourth_projection.copy()
test2222 = sp.sparse.vstack([Ghat_El,fourth_projection])
testzz = test2222.tocsr()
test222 = A1.getrow(1)




maybe = Ghat_El.todense()




#for vstack info
#https://stackoverflow.com/questions/60827979/joining-scipy-sparse-matrices-without-the-slow-scipy-sparse-vstack

