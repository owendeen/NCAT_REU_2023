# -*- coding: utf-8 -*-
"""
this is the file for doing the spline apxs
"""
import numpy as np
from scipy.sparse.csgraph import laplacian



def spline_apx(apxs_from_sprs , count_entries):
    
    ordered_inds = list(np.argsort(apxs_from_sprs))
    ordered_inds.reverse()
    diffs_in_spsty = list(np.zeros(len(apxs_from_sprs)-1))    # "distances" initialized
    
    for k in  range(len(diffs_in_spsty)):
        diffs_in_spsty[k] = count_entries[ordered_inds[-(k+1)]] - count_entries[ordered_inds[-(k+2)]]
        #distance         =  nonzeros of smallest pattern       -   nonzeros of second smallest pattern    etc.

    adjacency_arr = np.zeros(( len(apxs_from_sprs) , len(apxs_from_sprs) ))
    for k in range(len(diffs_in_spsty)):
        weightt = (1 / diffs_in_spsty[k])       #weight and distance arent "normalized" to anything
        adjacency_arr[k,k+1] = weightt
        adjacency_arr[k+1,k] = weightt

    lap_arr = laplacian(adjacency_arr)
    
    A_ = lap_arr[:,-1]                         #only the last two cols of the laplacian::: (-2,-1) for last two. -1 for last 1
    A_ = np.reshape(A_, (len(A_),1))                #necessary for predicting only last column

    b_ = -np.matmul( lap_arr[:,:-1], apxs_from_sprs[:-1])    #all but the last two cols of the laplacian
    b_ = np.reshape(b_, (len(b_),1))                #necessary for predicting only last column

    y = np.linalg.lstsq(A_,b_ )
    spline_apx_ = y[0]
    
    return(spline_apx_ , adjacency_arr)
        
        
