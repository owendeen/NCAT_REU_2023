# -*- coding: utf-8 -*-
"""
ghat and apx file
"""


"""
function: pat apx
	intake: A, sps pattern
		sps pattern tril
		slices according to projections row by row
		assemble rows
	output: apx, Ghat_El (if true)
"""


import numpy as np
import scipy as sp
from scipy.sparse import csr_matrix
from scipy.sparse import linalg     #not sure if needed
from scipy.sparse import coo_matrix

def pat_apx(A , pattern):
    m,n = A.get_shape()
    pat = sp.sparse.tril(pattern, format='csr')
    base = sp.sparse.csr_array((n,n))
    Ghat_El_rows = list(np.zeros(n))
    for i in range(n): #i is the row we work with in A
        nonzero_cols = pat.indices[pat.indptr[i]:pat.indptr[i+1]] #in row i, col number of nonzeros
        
        first_projection = sp.sparse.linalg.inv( (A[ nonzero_cols ,:])[:,nonzero_cols]  )  #slice according to projection then inverse then slice then slice
        
        second_projection = sp.sparse.csr_array((n,len(nonzero_cols)))
        second_projection[ nonzero_cols , 0:len(nonzero_cols) ]   =  first_projection 
        
        third_projection = base.copy()
        third_projection[ : , nonzero_cols ] = second_projection
        
        fourth_projection = sp.sparse.csr_array.transpose(third_projection[:,[i]]).tocsr()   #the e_i projection
        #maybe I should delete the "first projection" and stuff after I use them to open some memory up
        #while it's running
        
        Ghat_El_rows[i] = fourth_projection.copy() #idk if the copy is necessary
        

    
    Ghat_El = sp.sparse.vstack(Ghat_El_rows).tocsr()
    diagonals = sp.sparse.csr_matrix.diagonal(Ghat_El) **(-1/n)
    apx = np.prod(diagonals)
    print("Ghat_El and apx complete")
        
    return(apx, Ghat_El, n)




































