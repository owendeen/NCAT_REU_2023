# -*- coding: utf-8 -*-
"""
visualization functions
"""
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np

def visualize(apxs_from_sprs , spline_apx_ , adjacency_arr, calculate_actual_value = False, actual_value = 0):
    
    apxs_from_sprs = list(np.sort(apxs_from_sprs))
    apxs_from_sprs.reverse()
    round_adj_arr = np.around(adjacency_arr,decimals=3)


    graph_arr = nx.from_numpy_array(round_adj_arr, create_using=nx.Graph)
            #not sure if we want digraph or not
    layout = nx.circular_layout(graph_arr)
            #can use different layouts
    nx.draw_networkx(graph_arr,layout)
    #labels = nx.get_edge_attributes(graph_arr, "weight")
    #nx.draw_networkx_edge_labels(graph_arr, pos=layout, edge_labels=labels)
    plt.show()


    plt.plot([j+1 for j in range(len(apxs_from_sprs))],apxs_from_sprs, 'o')
    #plt.plot( [len(apxs)-2,len(apxs)-1], spline_apx_, '^',mfc = 'r')   #for two approxs
    plt.plot(len(apxs_from_sprs), spline_apx_, '^',mfc = 'r')     #for one approxs
    caption = '''the blue ones are the approximations from the sparsity patterns (A1, A2, A3, A4). 
    the orange is the approximation of the A4. star is actual'''
    plt.figtext(0.5, 0, caption, wrap=True, horizontalalignment='center', fontsize=8)  #caption
    
    if calculate_actual_value:
        plt.plot(len(apxs_from_sprs), actual_value, '*',mfc = 'b')
    plt.show()











