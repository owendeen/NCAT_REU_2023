# -*- coding: utf-8 -*-
"""
main file
"""
import numpy as np
import scipy as sp
from generate_matrices import laplacian_grid, florida_sparse
from pat_apx import pat_apx
from pat_rem_apx import pat_rem_apx
from spline_apx import spline_apx
from visualize import visualize


dim_enter = 10
A = laplacian_grid(dim_enter) 
calculate_actual_value = True

m,n = A.get_shape()

if calculate_actual_value:
    A_LU = sp.sparse.linalg.splu(A)     # LU decomp
    actual_det = A_LU.L.diagonal().prod() * A_LU.U.diagonal().prod()      #product of the products of the diagonal entries of the LU decomp
    actual_value_calculated = actual_det**(1 / (n))

apxs_from_sprs , Ghat_El_list , count_entries = pat_rem_apx(A, num_of_rem_pats = 5 , list_Ghats = True)



spline_apx_ , adjacency_arr = spline_apx(apxs_from_sprs , count_entries)

visualize(apxs_from_sprs , spline_apx_ , adjacency_arr, calculate_actual_value = True, actual_value = actual_value_calculated)
