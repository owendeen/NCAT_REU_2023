# -*- coding: utf-8 -*-
"""
the function for creating the patterns from removing small values
"""

"""
function: spspat removal apx
	intake: A, ToF Ghat_El
		1, creates sps pattern s1 based on A and stores
		calls function: pat apx
		2, creates sps pattern s2 (squares s1 then removes lowest)
		calls function: pat apx
		3, creates s3 (squares and removes lowest from s3)
		calls function: pat apx
		4, repeat 3,
			*these sps pats aren't tril
	output: list of apxs, ToF Ghat_El
"""
import numpy as np
import scipy as sp
from scipy.sparse import csr_matrix
from scipy.sparse import linalg
from scipy.sparse import coo_matrix
from pat_apx import pat_apx


def pat_rem_apx(A , num_of_rem_pats = 3 , list_Ghats = True):
    A1 = A != 0
    Ghat_El_list = list(np.zeros(num_of_rem_pats+1))      #initilize Ghat list
    apxs_from_sprs = list(np.zeros(num_of_rem_pats+1))                 #initilize apxs list
    count_entries = list(np.zeros(num_of_rem_pats+1))
    
    apx , Ghat_El, n = pat_apx(A, A1)     #calculate the apx and Ghat of A1
    
    apxs_from_sprs[0] = apx
    if list_Ghats == True:
        Ghat_El_list[0] = Ghat_El
        
    count_entries[0] = len(Ghat_El.data)

    
    
    for k in range(1, num_of_rem_pats+1 ): 
        if n >1000: rsplit = 100 ; num_of_splits = int(n/rsplit) #deciding how to split the rows of A
        elif n<20: rsplit = 1 ; num_of_splits =n
        else: rsplit = int(n/20) ; num_of_splits =20
        
        #rsplit = n ; num_of_splits = 1
        all_split_mx = [] 
        #split the matrix by rows
        for jj in range(num_of_splits):
            
            split_mx = Ghat_El[jj*rsplit:(jj+1)*rsplit , : ]
            all_split_mx.append(split_mx)   
            
            tenth_ = int(len(split_mx.data)/10) -1 #tenth of the values in the split
            values_to_lose = (np.argpartition( split_mx.data,tenth_,0))[0:tenth_+1 ]
            split_mx.data[values_to_lose] = 0
            #the 
            
            if (jj==num_of_splits-1) and not((n%rsplit == 0)):  #if there is a remainder, will do a slice of remaining rows
                split_mx = Ghat_El[(jj+1)*rsplit: , : ]
                all_split_mx.append(split_mx)   
            
                tenth_ = int(len(split_mx.data)/10) -1 #tenth of the values in the split
                values_to_lose = (np.argpartition( split_mx.data,tenth_,0))[0:tenth_+1 ]
                split_mx.data[values_to_lose] = 0      #removing the small values


        Ghat_wo_smalls = sp.sparse.vstack(all_split_mx)
        if (0 in sp.sparse.csr_matrix.diagonal(Ghat_wo_smalls)):
            print('Error, one of the diagonals was made zero when making the in-betweens')
        
        pattern_wo_smalls = Ghat_wo_smalls != 0
        #make boolean pattern from removing the small values (this is a smaller sparsity pattern than A1)
        
        pattern_wo_smalls_squared = pattern_wo_smalls**2
        
        apx , Ghat_El, n = pat_apx(A, pattern_wo_smalls_squared)
        
        apxs_from_sprs[k] = apx
        
        if list_Ghats == True:
            Ghat_El_list[k] = Ghat_El
        
        count_entries[k] = len(Ghat_El.data)
            
    return( apxs_from_sprs , Ghat_El_list , count_entries )
    


