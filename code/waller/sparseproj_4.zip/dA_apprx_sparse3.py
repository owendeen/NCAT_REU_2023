# -*- coding: utf-8 -*-
"""
Function for approximating d(A) using the Ghat_{E^{l}} construction.

I takes in the actual matrix to be apprx. It also takes in a NOT tril 
(well it could be tril, it wouldnt error; thered be a redundant line tho)
sparsity pattern in the form of a csr array (should be boolean entries).

it returns the apprx. can return Ghat_{E^{l}} if we want it to
"""

import numpy as np
import scipy as sp
from scipy.sparse import csr_matrix
from scipy.sparse import linalg
from scipy.sparse import coo_matrix


def our_csr_apprx(A, pattern):
    #A is matrix to apprx d(A) and pattern is csr boolean
    m,n = A.get_shape()
    pat = sp.sparse.tril(pattern, format='csr')
    base = sp.sparse.csr_array((n,n))
    for i in range(n): #i is the row we work with in A
        nonzero_cols = pat.indices[pat.indptr[i]:pat.indptr[i+1]] #in row i, col number of nonzeros
        
        first_projection = sp.sparse.linalg.inv( (A[ nonzero_cols ,:])[:,nonzero_cols]  )  #slice according to projection then inverse then slice then slice
        
        second_projection = sp.sparse.csr_array((n,len(nonzero_cols)))
        second_projection[ nonzero_cols , 0:len(nonzero_cols) ]   =  first_projection 
        
        third_projection = base.copy()
        third_projection[ : , nonzero_cols ] = second_projection
        
        fourth_projection = sp.sparse.csr_array.transpose(third_projection[:,[i]]).tocsr()   #the e_i projection
        
        #maybe I should delete the "first projection" and stuff after I use them to open some memory up
        #while it's running
        
        if i == 0:
            Ghat_El = (fourth_projection.copy())
        else:
            Ghat_El = sp.sparse.vstack([Ghat_El, (fourth_projection.copy())])
    Ghat_El = Ghat_El.tocsr()
    diagonals = sp.sparse.csr_matrix.diagonal(Ghat_El) **(-1/n)
    apprx = np.prod(diagonals)
    print("Ghat_El and apprx complete")
        
    return(apprx, Ghat_El, n)
    

def aprx_from_orders_of_A(A, orders_of_A):
    A1 = A != 0
    sprs_ptts = list(np.zeros((orders_of_A*2-1)) )
    sprs_ptts[0] = A1
    for k in range(1,orders_of_A):
        sprs_ptts[k*2] = ( A1**(k+1))
    #^generate sparsity patterns up to orders_of_A
    
    Ghat_El_list = list(np.zeros((orders_of_A*2-1)) )
    aprxs_from_sprs = list(np.zeros((orders_of_A*2-1)) )
    for k in range(orders_of_A):
        s = sprs_ptts[k*2]
        d_A , Ghat_El, n = our_csr_apprx(A, s)
        aprxs_from_sprs[k*2] = d_A 
        Ghat_El_list[k*2] = Ghat_El
        
        #start of inbetween generation. If A2 then goes back to make A1.5
        if (k > 0):
            if n >1000: rsplit = 100 ; num_of_splits = int(n/rsplit)
            elif n<20: rsplit = 1 ; num_of_splits =n
            else: rsplit = int(n/20) ; num_of_splits =20
            
            all_split_mx = [] 
            #split the matrix by rows
            for j in range(num_of_splits):
                
                split_mx = Ghat_El[j*rsplit:(j+1)*rsplit , : ]
                #all_split_mx.append(split_mx)   move down   
                
                tenth_ = int(len(split_mx.data)/10) -1 #tenth of the values in the split
                values_to_lose = (np.argpartition( split_mx.data,tenth_,0))[0:tenth_+1 ]
                split_mx.data[values_to_lose] = 0
                    #the 
                all_split_mx.append(split_mx)
                    
                if (j==num_of_splits-1) and not((n%rsplit == 0)):  #if there is a remainder, will do a slice of remaining rows
                    split_mx = Ghat_El[(j+1)*rsplit: , : ]
                    #all_split_mx.append(split_mx)   move down
                    
                    tenth_ = int(len(split_mx.data)/10) -1 #tenth of the values in the split
                    values_to_lose = (np.argpartition( split_mx.data,tenth_,0))[0:tenth_+1 ]
                    split_mx.data[values_to_lose] = 0
                    all_split_mx.append(split_mx)

            new_A_inbetween = sp.sparse.vstack(all_split_mx)
            if (0 in sp.sparse.csr_matrix.diagonal(new_A_inbetween)):
                print('Error, one of the diagonals was made zero when making the in-betweens')
            
            A_inbetweenpattern = new_A_inbetween != 0
            #make boolean pattern
            
            sprs_ptts[k*2-1] = A_inbetweenpattern
            
            d_A , Ghat_El, n = our_csr_apprx(A, A_inbetweenpattern)
            aprxs_from_sprs[k*2-1] = d_A
            Ghat_El_list[k*2-1] = Ghat_El
            
        
        
    return(aprxs_from_sprs,Ghat_El_list,sprs_ptts)
    


